import React from "react";
import UserInformation from "../userInformation";

const DefaultPage: React.FC = () => {
  return <UserInformation />;
};

export default DefaultPage;
